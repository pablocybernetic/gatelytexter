const Map<String, String> mccToIso = {
  '639': 'KE', // Kenya
  '234': 'GB', // UK
  '310': 'US', // USA
  // … add more as needed or pull from a JSON
};
