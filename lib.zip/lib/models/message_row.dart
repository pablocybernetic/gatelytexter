import 'package:gately/services/license_manager.dart'; // ← NEW

class MessageRow {
  MessageRow({required this.numbers, required this.body, this.status = ''});

  ///  Numbers already split & trimmed (see the factory below)
  List<String> numbers;

  /// Text message for every number in [numbers].
  String body;

  /// UI updates this as the row progresses (“Waiting”, “Sent”, …).
  String status;

  /*──────────────── factory used by CSV / Excel loaders ─────────────*/
  ///
  /// `cols[0]` = “Send To” column (can contain many numbers)
  /// `cols[1]` = message
  ///
  factory MessageRow.fromCsv(List<String> cols) {
    final raw = cols[0];
    final parts =
        raw
            .split(RegExp(r'[;,]')) // 1️⃣ split on ; or ,
            .expand((s) => s.split(RegExp(r'\s+'))) // 2️⃣ split on whitespace
            .map((s) => s.trim())
            .where((s) => s.isNotEmpty)
            .toList();

    // 3️⃣  free edition → keep only the *first* number
    final edition = LicenseManager.instance.edition;
    final numbers = edition == Edition.paid ? parts : parts.take(1).toList();

    return MessageRow(
      numbers: numbers,
      body: cols.length > 1 ? cols[1].trim() : '',
    );
  }

  /* Optional helper when you create rows manually elsewhere */
  MessageRow.single(String number, String message)
    : numbers = [number.trim()],
      body = message.trim(),
      status = '';
}
